Imports FFP.Utilities.Extensions

Namespace CSLA
    Public MustInherit Class BasicRuleDictionary
        Implements IRulePackage

        Public Sub New()

        End Sub

        Public Property RuleClasses As Dictionary(Of Type, List(Of ITypeRules))
        Public Property GoodGroups() As List(Of String) = New List(Of String)()
        Public Property BadGroups() As List(Of String) = New List(Of String)()

        Public Sub Setup() Implements IRulePackage.Setup
            AddRuleClasses()
        End Sub

        Private lvTypes As IEnumerable(Of Type)
        Public Property Types As IEnumerable(Of Type) Implements IRulePackage.Types
            Get
                If lvTypes Is Nothing Then
                    lvTypes = MakeTypes()
                End If
                Return lvTypes
            End Get
            Set(ByVal value As IEnumerable(Of Type))
                lvTypes = value
            End Set
        End Property

        Protected MustOverride Function MakeTypes() As IEnumerable(Of Type)


        Protected Overridable Sub AddRuleClasses()
            If RuleClasses Is Nothing Then
                RuleClasses = New Dictionary(Of Type, List(Of ITypeRules))
                For Each tp As System.Type In Types()
                    If tp.GetInterfaces().Contains(GetType(ITypeRules)) AndAlso tp.IsAbstract.IsFalse AndAlso IsProperGroup(tp) Then
                        Dim classRules As ITypeRules = CType(System.Activator.CreateInstance(tp), ITypeRules)
                        For Each clsTp As Type In classRules.TypeFor
                            If RuleClasses.ContainsKey(clsTp).IsFalse Then
                                RuleClasses.Add(clsTp, New List(Of ITypeRules))
                            End If
                            RuleClasses(clsTp).Add(classRules)
                        Next

                    End If
                Next
            End If
        End Sub

        Protected Overridable Function IsProperGroup(theType As Type) As Boolean
            If HasGroups() Then
                If IsGoodGroup(theType) Then
                    Return True
                End If

                If IsBadGroup(theType) Then
                    Return False
                End If
            Else
                Return True
            End If
        End Function

        Protected Function HasGroups() As Boolean
            If BadGroups.IsEmpty AndAlso GoodGroups.IsEmpty Then
                Return False
            Else
                Return True
            End If
        End Function

        Protected Function IsBadGroup(theType As Type) As Boolean
            If BadGroups.IsEmpty Then
                Return False
            ElseIf Attribute.IsDefined(theType, GetType(RuleGroupAttribute)) Then
                Dim ruleGroup As RuleGroupAttribute = CType(Attribute.GetCustomAttribute(theType, GetType(RuleGroupAttribute)), RuleGroupAttribute)
                If ruleGroup.Groups.Contains(From itm As String In BadGroups Select itm.Trim.ToUpper) Then
                    Return True
                End If
            End If
            Return False
        End Function

        Protected Function IsGoodGroup(theType As Type) As Boolean
            If GoodGroups.IsEmpty Then
                Return False
            ElseIf Attribute.IsDefined(theType, GetType(RuleGroupAttribute)) Then
                Dim ruleGroup As RuleGroupAttribute = CType(Attribute.GetCustomAttribute(theType, GetType(RuleGroupAttribute)), RuleGroupAttribute)
                If ruleGroup.Groups.Contains(From itm As String In GoodGroups Select itm.Trim.ToUpper) Then
                    Return True
                End If
            End If
            Return False
        End Function

        Public MustOverride ReadOnly Property PackageName() As String Implements CSLA.IRulePackage.PackageName

        Public Overrides Function ToString() As String
            Return PackageName
        End Function

        Public Overrides Function GetHashCode() As Integer
            Return Me.PackageName.GetHashCode
        End Function

        Public Overrides Function Equals(ByVal obj As Object) As Boolean
            If TypeOf obj Is IRulePackage Then
                If CType(obj, IRulePackage).PackageName = Me.PackageName Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End Function

        Public Sub CheckRules(ByVal obj As IRulesChecked) Implements IRulePackage.CheckBusinessRules
            If RuleClasses.ContainsKey(obj.GetType) Then
                For Each clasRules As ITypeRules In RuleClasses(obj.GetType)
                    clasRules.CheckRules(obj)
                Next
            End If
        End Sub

        Public Function ListRules(ByVal obj As IRuledItem, includeDeleteRules As Boolean) As IEnumerable(Of IRule) Implements IRulePackage.ListRules
            Return TypeRules(obj.GetType, includeDeleteRules)
        End Function

        Public Sub CheckDeleteRules(ByVal obj As IRulesChecked) Implements CSLA.IRulePackage.CheckDeleteRules
            If RuleClasses.ContainsKey(obj.GetType) Then
                For Each clasRules As ITypeRules In RuleClasses(obj.GetType)
                    clasRules.CheckDeleteRules(obj)
                Next
            End If
        End Sub

        Public Function TypeRules(objType As Type, includeDeleteRules As Boolean) As System.Collections.Generic.IEnumerable(Of IRule) Implements IRulePackage.TypeRules
            Dim lst As New List(Of IRule)
            If RuleClasses.ContainsKey(objType) Then
                For Each itm As ITypeRules In RuleClasses(objType)
                    lst.AddRange(itm.ListOfRules(includeDeleteRules))
                Next
                Return lst
            End If
            Return lst
        End Function
    End Class

End Namespace
