Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    <Serializable()> Public Class ValueRangeRuleHelper
        Public FromValue As IComparable
        Public ToValue As IComparable
        Public Sub New(ByVal fromval As IComparable, ByVal toval As IComparable)
            FromValue = fromval
            ToValue = toval
        End Sub
    End Class
End Namespace
