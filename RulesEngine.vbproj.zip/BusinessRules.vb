Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA

    ''' <summary>
    ''' Tracks the business rules broken within a business object.
    ''' </summary>
    <Serializable()> Public Class BusinessRules


        <NonSerialized()> Private mTarget As IRuledItem

        ''' <summary>
        ''' Sets the target object so the Rules Manager functionality
        ''' has a reference to the object containing the data to
        ''' be validated.
        ''' </summary>
        ''' <remarks>
        ''' The object here is typically your business object. In your
        ''' business class you'll implement a method to set up your
        ''' business rules. As you do so, you need to call this method
        ''' to give BrokenRules a reference to your business object
        ''' so it has access to your object's data.
        ''' </remarks>
        ''' <param name="target">A reference to the object containing
        ''' the data to be validated.</param>
        Public Sub New(ByVal target As IRuledItem)
            lvBrokenRules = New BrokenRules
            mTarget = target
        End Sub

        Private Sub New()

        End Sub

        Public Function ForTarget(bo As IBusinessBase) As Boolean
            If bo Is Nothing OrElse mTarget Is Nothing Then
                Return False
            Else
                Return bo.Equals(mTarget)
            End If
        End Function


        Public Function Count() As Integer
            If lvRulesList Is Nothing Then
                Return 0
            Else
                Return lvRulesList.Count
            End If
        End Function

        <NonSerialized()>
        Private lvRulesList As List(Of IRule)
        Public Function RulesList() As List(Of IRule)
            If lvRulesList Is Nothing Then
                lvRulesList = New List(Of IRule)
            End If
            Return lvRulesList
        End Function



        Public Sub AddRule(ByVal rule As IRule)
            If rule Is Nothing Then
                Return
            Else
                If rule.BusinessObject Is Nothing Then
                    rule.BusinessObject = Me.mTarget
                End If
                RulesList.Add(rule)
            End If
        End Sub


        Friend Sub Clear()
            Me.RulesList.Clear()
            lvBrokenRules.Clear()
        End Sub


        ''' <summary>
        ''' Checks all the rules for a specific Property.
        ''' </summary>
        ''' <param name="propName">The PropertyName to be validated.</param>
        Public Sub CheckRulesByProperty(ByVal propName As String)
            For Each rule As IRule In RulesList()
                If rule.HandlesProperty(propName) Then
                    If rule.IsBroken Then
                        BrokenRules.Add(rule)
                    Else
                        BrokenRules.Remove(rule)
                    End If
                End If
            Next
        End Sub

        ''' <summary>
        ''' Checks all the rules for a target object.
        ''' </summary>
        Public Sub CheckRules()
            BrokenRules.Clear()
            For Each rule As IRule In RulesList()
                If rule.IsBroken Then
                    BrokenRules.Add(rule)
                Else
                    BrokenRules.Remove(rule)
                End If
            Next
        End Sub

        Private lvBrokenRules As BrokenRules
        Public ReadOnly Property BrokenRules() As BrokenRules
            Get
                Return lvBrokenRules
            End Get
        End Property

        Public ReadOnly Property IsValid() As Boolean
            Get
                CheckRules()
                For Each item As IRule In BrokenRules
                    If item.Severity <= RuleSeverity.Critical Then
                        Return False
                    End If
                Next
                Return True
            End Get
        End Property

        Public Function IsBroken(ByVal ruleName As String) As Boolean
            CheckRules()
            Return BrokenRules.Contains(ruleName)
        End Function

        Public Function GetBrokenRules() As BrokenRules
            CheckRules()
            Return BrokenRules
        End Function

        Private Function BrokenRulesString() As String
            CheckRules()
            Return (From item As IRule In BrokenRules Select item.Description).ListToString(",")
        End Function

        Public Function BrokenRulesForSeverity(ByVal severity As RuleSeverity) As IEnumerable(Of IRule)
            CheckRules()
            Return From itm As IRule In BrokenRules Where itm.Severity = severity
        End Function

        Public Overrides Function ToString() As String
            Return BrokenRulesString()
        End Function

    End Class
End Namespace