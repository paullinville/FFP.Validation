Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA

    <Serializable()> Public Class BrokenRules
        Inherits System.Collections.ObjectModel.Collection(Of IRule)

        Friend Overloads Sub Add(ByVal rule As IRule)
            If IgnoreRule(rule.RuleName) Then
                Return
            Else
                If Not Contains(rule) Then
                    MyBase.Add(rule)
                End If
            End If
        End Sub

        Private Function IgnoreRule(ByVal ruleName As String) As Boolean
            'todo replace with channel event
        End Function

        Public Overloads Function Contains(ByVal RuleName As String) As Boolean
            For Each itm As IRule In Me
                If itm.RuleName = RuleName Then
                    Return True
                End If
            Next
            Return False
        End Function

        Public Sub AddRules(itm As IRulesChecked)
            If itm.IsValid Then Return

            For Each rule As IRule In itm.BrokenRuleList
                Me.Add(rule)
            Next
        End Sub

        Public Sub AddRules(itms As IEnumerable(Of IRulesChecked))
            For Each itm As IRulesChecked In itms
                AddRules(itm)
            Next
        End Sub

        Public Sub AddRange(brokenRules As IEnumerable(Of IRule))
            For Each itm As IRule In brokenRules
                Add(itm)
            Next
        End Sub
    End Class
End Namespace
