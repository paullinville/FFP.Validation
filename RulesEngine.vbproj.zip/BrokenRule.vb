Option Strict Off
Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.CoreUtilities
Imports FFP.Utilities

Namespace CSLA
    Public Class BrokenRule
        Implements IRule

        Private Property IRuledItemID As Guid
        Public Sub New(ByVal rle As IRule)
            IsBroken = True
            With rle
                AllowedValue = .AllowedValue
                Description = .Description

                PropertyName = .PropertyName
                PropertyValue = .PropertyValue
                RuleName = .RuleName
                Severity = .Severity
                IRuledItemID = rle.BusinessObject.IfNullBOID
            End With
            If TypeOf rle Is MultiPropertyRule Then
                lvProperties = New List(Of String)
                Dim mpRule As MultiPropertyRule = CType(rle, MultiPropertyRule)
                For Each loopPropName As String In mpRule.Properties
                    lvProperties.Add(loopPropName)
                Next
            End If
        End Sub

        Public Sub New(ByVal name As String, ByVal desc As String, ByVal propName As String, ByVal sev As RuleSeverity)
            IsBroken = True
            Description = desc & ""
            PropertyName = propName & ""
            RuleName = name & ""
            Severity = sev
        End Sub

        Public Sub New(objectBroke As IIdentifiable, ByVal name As String, ByVal desc As String, ByVal propName As String, ByVal sev As RuleSeverity)
            IsBroken = True
            Description = desc & ""
            PropertyName = propName & ""
            RuleName = name & ""
            IRuledItemID = objectBroke.IfNullBOID
            Severity = sev
        End Sub


        Public Property AllowedValue() As Object Implements IRule.AllowedValue

        Public Property Description() As String Implements IRule.Description

        Private lvProperties As List(Of String)
        Public Function HandlesProperty(ByVal propName As String) As Boolean Implements IRule.HandlesProperty
            If lvProperties IsNot Nothing Then
                Return PropertyName.CompareAbsolute(propName) OrElse lvProperties.ContainsAbsolute(propName)
            Else
                Return PropertyName.CompareAbsolute(propName)
            End If
        End Function

        Public Property IsBroken() As Boolean Implements IRule.IsBroken

        Public Property PropertyName() As String Implements IRule.PropertyName

        Public Property PropertyValue() As Object Implements IRule.PropertyValue

        Public Property RuleName() As String Implements IRule.RuleName

        Public Property Severity() As RuleSeverity Implements IRule.Severity

        Public Property BusinessObject As IRulesChecked Implements IRule.BusinessObject

        Public Overrides Function Equals(obj As Object) As Boolean
            If TypeOf obj Is BrokenRule Then
                Dim OTHER As IRule = CType(obj, IRule)
                Return identifier(Me) = identifier(OTHER)
            Else
                Return MyBase.Equals(obj)
            End If
        End Function

        Public Overrides Function GetHashCode() As Integer
            Return identifier(Me).GetHashCode
        End Function

        Private Function identifier(broke As BrokenRule) As String
            Return broke.PropertyName & broke.IRuledItemID.ToString & broke.RuleName & broke.Severity.EnumName
        End Function


    End Class
End Namespace
