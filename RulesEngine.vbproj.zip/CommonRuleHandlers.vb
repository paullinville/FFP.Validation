Option Strict On

Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    Public Class CommonRuleHandlers


        'Handlers return TRUE if the rule is broken and FALSE if it is not broken

        Public Shared Function NonEmptyGuidHandler(target As IRule) As Boolean
            If GuidUtil.ToGuid(target.PropertyValue).IsEmpty Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function EmptyGuidHandler(target As IRule) As Boolean
            If TypeOf target.BusinessObject Is IDeletable AndAlso CType(target.BusinessObject, IDeletable).IsDeleted Then
                Return False
            End If
            If GuidUtil.ToGuid(target.PropertyValue).IsEmpty Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Shared Function BetweenValueHandler(target As IRule) As Boolean
            If target.AllowedValue Is Nothing Then
                Return False
            End If

            Dim valRange As ValueRangeRuleHelper = CType(target.AllowedValue, ValueRangeRuleHelper)
            Dim val As IComparable = CType(target.PropertyValue, IComparable)
            Return Not val.Between(valRange.FromValue, valRange.ToValue)
        End Function

        Public Shared Function BetweenValueHandlerAllowMinValue(target As IRule) As Boolean
            Return False
            If target.AllowedValue Is Nothing Then
                Return False
            End If

            Dim valRange As ValueRangeRuleHelper = CType(target.AllowedValue, ValueRangeRuleHelper)
            Dim val As IComparable = CType(target.PropertyValue, IComparable)

            Return Not val.Between(valRange.FromValue, valRange.ToValue)
        End Function

        Public Shared Function DateRangeHandler(target As IRule) As Boolean
            If target.AllowedValue IsNot Nothing Then
                If Not CType(target.AllowedValue, IDateRange).InRange(CType(target.PropertyValue, Date)) Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End Function

        Public Shared Function LessThanHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) >= 0 Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function DateNotMinHandler(target As IRule) As Boolean
            If CDate(target.PropertyValue) = Date.MinValue Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function DateNotMaxHandler(target As IRule) As Boolean
            If CDate(target.PropertyValue) = Date.MaxValue Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function NotNullHandler(target As IRule) As Boolean
            If target.PropertyValue Is Nothing Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function GreaterThanHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) <= 0 Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function ValidSqlDateHandler(target As IRule) As Boolean
            If CDate(target.PropertyValue) = Date.MinValue Or CDate(target.PropertyValue) = Date.MaxValue Then
                Return False
            Else
                If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) <= 0 Then
                    Return True
                Else
                    Return False
                End If
            End If
        End Function

        Public Shared Function LessThanOrEqualToHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) <= 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Shared Function EqualToHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) = 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Shared Function NotEqualToHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) <> 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Shared Function GreaterThanOrEqualToHandler(target As IRule) As Boolean
            If CType(target.PropertyValue, IComparable).CompareTo(CType(target.AllowedValue, IComparable)) >= 0 Then
                Return False
            Else
                Return True
            End If
        End Function

        Public Shared Function NonBlankStringHandler(target As IRule) As Boolean
            Dim propVal As Object = target.PropertyValue
            If propVal IsNot Nothing Then
                Return propVal.ToString.IsEmpty()
            Else
                Return True
            End If
        End Function


        Public Shared Function MaxStringLengthHandler(target As IRule) As Boolean
            If target.PropertyValue Is Nothing Then
                Return False
            End If

            If target.PropertyValue.ToString.Length > CInt(target.AllowedValue) Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function MinStringLengthHandler(target As IRule) As Boolean
            If target.PropertyValue Is Nothing Then
                Return True
            End If

            If target.PropertyValue.ToString.Length < CInt(target.AllowedValue) Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Function IsNumberBroke(target As IRule) As Boolean

            Return IsNumeric(target.PropertyValue.ToString).IsFalse
        End Function

        Public Shared Function IsAdHocGuid(target As IRule) As Boolean
            Return GuidUtil.ToGuid(target.PropertyValue).ToString("N").StartsWith("0000000000000000000000")
        End Function
    End Class
End Namespace
