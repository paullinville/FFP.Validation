Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA

    <Serializable()> Public Class MultiPropertyRule
        Inherits Rule

        Public Sub New(ByVal Rule As String, ByVal Description As String)
            MyBase.New(Rule, Description)
        End Sub

        Public Sub New(ByVal Rule As String, ByVal Description As String, ByVal [Property] As String)
            MyBase.New(Rule, Description, [Property])
        End Sub

        Public Sub New(ByVal Rule As String, ByVal Description As String, ByVal [Property] As String, ByVal handler As RuleHandler)
            MyBase.New(Rule, Description, [Property], handler)
        End Sub

        Private lvProperties As New List(Of String)
        Public ReadOnly Property Properties() As List(Of String)
            Get
                Return lvProperties
            End Get
        End Property



        Public Overrides Property AllowedValue() As Object
            Get
                Return MyBase.AllowedValue
            End Get
            Set(ByVal value As Object)
                MyBase.AllowedValue = value
            End Set
        End Property

        Public Overrides Function HandlesProperty(ByVal propName As String) As Boolean
            Return MyBase.HandlesProperty(propName) OrElse Me.Properties.ContainsAbsolute(propName)
        End Function

    End Class
End Namespace
