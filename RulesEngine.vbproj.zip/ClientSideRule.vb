Imports FFP.CoreUtilities.Extensions
Imports FFP.CoreUtilities

Namespace CSLA

    Public Class ClientSideRule
        Inherits Rule
        Implements IClientRule

        Public Sub New(ByVal Rule As String, ByVal Description As String)
            MyBase.New(Rule, Description)
        End Sub

        Public Sub New(ByVal Rule As String, ByVal Description As String, ByVal [Property] As String)
            MyBase.New(Rule, Description, [Property])
        End Sub


        Public Function JavaScript() As String Implements IClientRule.JavaScript
            Dim bldr As New Text.StringBuilder

            bldr.Append("function(value) {if (")
            bldr.Append(RuleName.Replace(" ", "_"))
            bldr.Append("(value")

            If AllowedValue IsNot Nothing Then
                bldr.Append(String.Format(", {0}))", AllowedValueString()))
            Else
                bldr.Append("))")
            End If
            bldr.Append(" return ")
            bldr.Append(Description().Surround("'"))

            bldr.Append("; }")
            Return bldr.ToString
        End Function


        Public Function AllowedValueString() As String
            If TypeOf AllowedValue Is ValueRangeRuleHelper Then
                Return String.Format("{0}, {1}", TypeToString(CType(AllowedValue, ValueRangeRuleHelper).FromValue), TypeToString(CType(AllowedValue, ValueRangeRuleHelper).ToValue))
            ElseIf TypeOf AllowedValue Is IDateRange Then
                Return String.Format("{0}, {1}", CType(AllowedValue, IDateRange).FirstValidDate.JavaScriptDate, CType(AllowedValue, IDateRange).LastValidDate.JavaScriptDate)
            Else
                Return TypeToString(AllowedValue)
            End If
        End Function


        Public Function TypeToString(val As Object) As String
            If TypeOf val Is DateTime Then
                Return CDate(AllowedValue).JavaScriptDate()
            ElseIf TypeOf val Is Boolean Then
                Return AllowedValue.ToString.ToLower
            ElseIf TypeOf val Is String Then
                Return CStr(AllowedValue)
            ElseIf TypeOf val Is Decimal AndAlso CDec(val) <> 0 Then
                Dim tempVal As String = val.ToString
                Dim leftVal As String = tempVal.BeforeX(".", False)

                If leftVal.IsNotNullOrBlank Then
                    Dim rightVal As String = tempVal.AfterX(".", False)

                    Dim numberDecimals As Integer

                    If leftVal.StartsWith("-") Then
                        numberDecimals = 17 - leftVal.Length
                    Else
                        numberDecimals = 16 - leftVal.Length
                    End If

                    If numberDecimals > 0 Then
                        Return leftVal & "." & rightVal.Left(numberDecimals)
                    Else
                        Return leftVal & "." & rightVal
                    End If
                Else
                    Return tempVal
                End If


            Else
                Return val.ToString
            End If
        End Function

    End Class

End Namespace
