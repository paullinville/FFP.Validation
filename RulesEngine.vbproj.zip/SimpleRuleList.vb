Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.CoreUtilities
Imports System.Reflection

Namespace CSLA
    Public Class SimpleRuleList
        Inherits List(Of IRule)

        Public Sub AddRule(ByVal rule As IRule)
            Me.Add(rule)
        End Sub

    End Class


End Namespace
