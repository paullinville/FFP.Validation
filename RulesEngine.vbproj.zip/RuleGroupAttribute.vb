Imports FFP.Utilities.Extensions

Namespace CSLA
    <AttributeUsage(AttributeTargets.Class)>
    Public Class RuleGroupAttribute
        Inherits Attribute

        Public Sub New(group As String)
            lvGroups.Add(group.Trim.ToUpper)
        End Sub

        Public Sub New(grpLst As String, delimiter As Char)
            If grpLst IsNot Nothing Then
                lvGroups.AddToHashSet(From itm As String In grpLst.Split(delimiter) Select itm.ToUpper.Trim Distinct)
            End If
        End Sub

        Private lvGroups As New HashSet(Of String)
        Public ReadOnly Property Groups As HashSet(Of String)
            Get
                Return lvGroups
            End Get
        End Property
    End Class

End Namespace
