Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.CoreUtilities

Namespace CSLA
    Public Class CommonRules

        Public Const EqualToRuleName As String = "Equal To"
        Public Shared Function NotNothingRule(propName As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Not Nothing", "Value must be set.", propName)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.NotNullHandler
            newRule.Severity = severity
            Return newRule

        End Function

        Public Shared Function DateNotMinRule(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Date Not Min", "Date must be set.", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.DateNotMinHandler
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function DateNotMaxRule(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Date Not Max", "Date must be less than " & Date.MaxValue.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.DateNotMinHandler
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function MaxStringLengthRule(propname As String, maxLength As Integer, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newrule As New ClientSideRule("Max String Length", "Length of string cannot exceed " & maxLength.ToString & " characters.", propname)
            newrule.AllowedValue = maxLength
            newrule.RuleHandler = AddressOf CommonRuleHandlers.MaxStringLengthHandler
            newrule.Severity = severity
            Return newrule
        End Function

        Public Shared Function MinStringLengthRule(propname As String, minLength As Integer, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newrule As New ClientSideRule("Min String Length", "Length of string must be at least " & minLength.ToString & " characters.", propname)
            newrule.AllowedValue = minLength
            newrule.RuleHandler = AddressOf CommonRuleHandlers.MinStringLengthHandler
            newrule.Severity = severity
            Return newrule
        End Function

        Public Shared Function NotEmptyStringRule(PropName As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Not Empty", "Value cannot be empty.", PropName)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.NonBlankStringHandler
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function GuidNotEmpty(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("GUID Not Empty", "Item cannot be empty.", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.NonEmptyGuidHandler
            newRule.Severity = severity
            Return newRule
        End Function


        Public Shared Function GuidEmpty(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("GUID Empty", "Item must be empty.", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.EmptyGuidHandler
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function ValidSqlDateRule(propName As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Valid SQL Date", "Value must be greater than 1/1/1753.", propName)
            newRule.AllowedValue = #1/1/1753#
            newRule.RuleHandler = AddressOf CommonRuleHandlers.ValidSqlDateHandler
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function GreaterThanRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Greater Than", "Value must be greater than " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.GreaterThanHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function


        Public Shared Function LessThanRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Less Than", "Value must be less than " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.LessThanHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function GreaterThanOrEqualToRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Greater Than Or Equal To", "Value must be greater than or equal to " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.GreaterThanOrEqualToHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function LessThanOrEqualToRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Less Than Or Equal To", "Value must be less than or equal to " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.LessThanOrEqualToHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function BetweenRule(propname As String, fromVal As IComparable, toval As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Between", "Value must be between " & fromVal.ToString & " and " & toval.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.BetweenValueHandler
            newRule.AllowedValue = New ValueRangeRuleHelper(fromVal, toval)
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function BetweenRule(propname As String, range As IDateRange, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Date Between", "Date must be between " & range.FirstValidDate.ToString & " and " & range.LastValidDate.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.DateRangeHandler
            newRule.AllowedValue = range
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function NumberRangeRuleAllowMin(propname As String, intPartLength As Byte, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule

            Dim number As Decimal
            If intPartLength = 0 Then
                number = 0.9999999999999999999999999999D
            Else
                Dim numStr As String
                For i As Byte = 1 To intPartLength
                    numStr &= "9"
                Next
                number = CDec(numStr)
            End If



            Dim range As New ValueRangeRuleHelper((number * -1), number)
            Dim newRule As New ClientSideRule("Number Range", "Number must be between " & (number).ToString & " and " & (number * -1).ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.BetweenValueHandlerAllowMinValue
            newRule.AllowedValue = range
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function NumberRangeRule(propname As String, intPartLength As Byte, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule

            Dim number As Decimal
            If intPartLength = 0 Then
                number = 0.9999999999999999999999999999D
            Else
                Dim numStr As String
                For i As Byte = 1 To intPartLength
                    numStr &= "9"
                Next

                numStr = numStr & "."
                numStr = numStr.PadRight(29, "9"c)
                number = CDec(numStr)
            End If



            Dim range As New ValueRangeRuleHelper((number * -1), number)
            Dim newRule As New ClientSideRule("Number Range", "Number must be between " & (number).ToString & " and " & (number * -1).ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.BetweenValueHandler
            newRule.AllowedValue = range
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function EqualToRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule(EqualToRuleName, "Value must be equal to " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.EqualToHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function NotEqualToRule(propname As String, value As IComparable, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Not Equal To", "Value must not be equal to " & value.ToString & ".", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.NotEqualToHandler
            newRule.AllowedValue = value
            newRule.Severity = severity
            Return newRule
        End Function


        Public Shared Function IsNotNumeric(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Is Not Numeric", "Value {0} is not a valid number.".FormatStr(propname), propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.IsNumberBroke
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function MustBeNullOrNumeric(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Must Be Null Or Numeric", "Value {0} is not a valid number.".FormatStr(propname), propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.IsNumberBroke
            newRule.Severity = severity
            Return newRule
        End Function

        Public Shared Function IsAdHocGuid(propname As String, Optional ByVal severity As RuleSeverity = RuleSeverity.Critical) As Rule
            Dim newRule As New ClientSideRule("Is Ad Hoc Guid", "Selected value not allowed.", propname)
            newRule.RuleHandler = AddressOf CommonRuleHandlers.IsAdHocGuid
            newRule.Severity = severity
            Return newRule
        End Function
    End Class
End Namespace