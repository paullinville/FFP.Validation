Imports FFP.DAL.Request
Imports CSLA.FFP
Imports FFP.BO.Interfaces
Imports FFP.Utilities.Extensions
Imports FFP.DAL

Namespace CSLA

    Public MustInherit Class BaseDuplicateDBFieldCheckerRules
        Inherits TypeRulesBase
        Public Const STR_ADuplicateValueWasFoundFor As String = "A {0} values must be unique. A duplicate code with value {1} was found."

        Public Sub New(BOIDFieldName As String, DuplicateFieldName As String, requestName As String)
            Me.BOIDFieldName = BOIDFieldName
            Me.FieldNameToCheckForDuplicate = DuplicateFieldName
            Me.RequestName = requestName
        End Sub

        Protected Overrides Sub AddClassRules()
            AddRule(New Rule("DuplicateFieldCheck", "") With {.RuleHandler = AddressOf CheckHasDuplicateBroke})
        End Sub

        Public Property BOIDFieldName As String
        Public Property FieldNameToCheckForDuplicate As String
        Public Property RequestName As String
        Public Function CheckHasDuplicateBroke(target As IRule) As Boolean
            'todo implement
            'If target.BusinessObject IsNot Nothing AndAlso TypeOf target.BusinessObject Is IEditableDomainModel Then
            '    If CType(target.BusinessObject, IEditableDomainModel).IsDeleted Then
            '        Return False
            '    ElseIf CType(target.BusinessObject, IEditableDomainModel).IsDirty.IsFalse Then
            '        Return False
            '    Else
            '        Dim boo As IBOOutline
            '        boo = RequestStorage.GetRequest(RequestName)
            '        Dim req As IDataRequest = boo.SelectRequest

            '        Dim bo As IRulesChecked = CType(target.BusinessObject, IRulesChecked)

            '        Dim result As Boolean = DataHelperMethods.CheckForDuplicateValues(req.ObjID,
            '                                                                          BOIDFieldName,
            '                                                                          bo.BOID,
            '                                                                          FieldNameToCheckForDuplicate,
            '                                                                          bo.PropertyValue(FieldNameToCheckForDuplicate),
            '                                                                          req.ConnectionStringName)

            '        If result Then
            '            target.Description = STR_ADuplicateValueWasFoundFor.FormatStr(FieldNameToCheckForDuplicate, bo.PropertyValue(FieldNameToCheckForDuplicate))
            '        End If
            '        Return result
            '    End If
            'Else
            '    Return False
            'End If
        End Function
    End Class
End Namespace
