Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    Public Class MultiPropertyRuleOutput
        Inherits RuleOutput

        Public Sub New(val As MultiPropertyRule)
            MyBase.New(val)
        End Sub



        Public Overrides Function Output() As String
            Dim strBld As New Text.StringBuilder
            If TypeOf Rule.BusinessObject Is IBusinessBase Then
                strBld.Append(CType(Rule.BusinessObject, IBusinessBase).FriendlyName.Trim())
            Else
                strBld.Append(Rule.BusinessObject.GetType.Name.Trim())
            End If

            strBld.Append(" Broken Rule with severity of ")
            strBld.Append(Rule.Severity.EnumName)
            strBld.Append(ControlChars.NewLine)
            For Each propName As String In CType(rule, MultiPropertyRule).Properties
                If Not String.IsNullOrEmpty(propName) Then
                    strBld.Append("Property: ")
                    strBld.Append(propName.Trim & ";")
                    strBld.Append(" Current Value: ")

                    If (rule.BusinessObject.PropertyValue(propName) Is Nothing) OrElse (TypeOf rule.BusinessObject.PropertyValue(propName) Is Guid AndAlso CType(rule.BusinessObject.PropertyValue(propName), Guid).IsEmpty) OrElse (TypeOf rule.BusinessObject.PropertyValue(propName) Is String AndAlso CType(rule.BusinessObject.PropertyValue(propName), String).IsEmpty) Then
                        strBld.Append(CSLA.Rule.STR_EMPTY)
                    Else
                        strBld.Append(rule.BusinessObject.PropertyValue(propName).ToString)
                    End If
                End If
            Next

            strBld.Append(ControlChars.NewLine)
            strBld.Append("Description: ")
            strBld.Append(rule.Description)
            strBld.Append(ControlChars.NewLine)
            Return strBld.ToString
        End Function
    End Class
End Namespace
