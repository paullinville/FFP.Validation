Namespace CSLA
    Public MustInherit Class TypeRuleDeleteBase(Of T)
        Inherits TypeRule(Of T)

        Public Sub New()
            AddTypeRule()
        End Sub

        Public Sub New(name As String, description As String)
            MyBase.New(name, description)
        End Sub

        Public Sub New(description As String)
            Me.New()
            Rule.Description = description
        End Sub

        Public Overrides Sub CheckRules(bo As IRulesChecked)
            'do nothing
        End Sub

        Public Overrides Sub CheckDeleteRules(bo As IRulesChecked)
            If Rule IsNot Nothing Then
                bo.AddDeleteBrokenRule(Rule.CheckRule(bo))
            End If
        End Sub

        Protected Overrides Function RuleName() As String
            Return GetType(T).Name & " Delete"
        End Function

        Protected Overrides Property RuleDescription() As String = "Cannot delete."

        Public Overrides Function ListOfRules(includeDelete As Boolean) As IEnumerable(Of IRule)
            If includeDelete Then
                Return {Rule}
            Else
                Return {}
            End If
        End Function
    End Class
End Namespace