﻿Imports System.Runtime.CompilerServices
Imports FFP.CoreUtilities.Extensions

Namespace CSLA


    Public Module RuleExtensions



            <Extension()> Public Function IsValid(ByVal val As BrokenRules) As Boolean
                Return val Is Nothing OrElse Not val.HasCritical
            End Function

            <Extension> Public Function BrokenRules(val As IEnumerable(Of IRule)) As String
                If val.IsEmpty Then
                    Return ""
                Else
                    Dim obj As New System.Text.StringBuilder

                    Dim first As Boolean = True

                    For Each item As IRule In val
                        If first Then
                            first = False
                        Else
                            obj.Append(vbCrLf)
                            obj.Append(vbCrLf)
                        End If
                        If item.PropertyName.IsNotNullOrBlank Then
                            obj.Append(item.PropertyName & " " & item.Description)
                        Else
                            obj.Append(item.Description)
                        End If
                    Next
                    Return obj.ToString.Trim
                End If
            End Function

            <Extension()> Public Function BrokenRulesString(ByVal val As IEnumerable(Of IRule)) As String
                Return BrokenRules(From itm As IRule In val.Values Where itm.IsBroken)
            End Function

            <Extension()> Public Function BrokenRulesString(ByVal val As IEnumerable(Of IRule), ByVal severity As RuleSeverity) As String
                Return BrokenRules(From itm As IRule In val.Values Where itm.IsBroken AndAlso itm.Severity = severity)
            End Function

            <Extension()> Public Function CheckRule(ByVal val As IRule, ByVal bo As IRulesChecked) As BrokenRule
                Dim rule As BrokenRule
                Try
                    val.BusinessObject = bo
                    If val.IsBroken Then
                        rule = New BrokenRule(val)
                    End If
                    Return rule
                Finally
                    val.BusinessObject = Nothing
                End Try
            End Function

            <Extension()> Public Function BrokenRulesForPropertyAndMaxRuleSevrity(ByVal val As BrokenRules, ByVal propName As String, ByVal severity As RuleSeverity) As String
                If val Is Nothing OrElse val.Count = 0 Then
                    Return ""
                Else
                    Dim brokenRuleString As New Text.StringBuilder
                    Dim lineEnd As String = ""
                    For Each Item As IRule In val
                        If Item.HandlesProperty(propName) AndAlso severity >= Item.Severity Then
                            brokenRuleString.Append(Item.Severity.EnumName & ": " & Item.Description)
                            brokenRuleString.Append(lineEnd)
                            lineEnd = ControlChars.NewLine & " "
                        End If
                    Next
                    Return brokenRuleString.ToString
                End If
            End Function

            <Extension()> Public Function HasCritical(ByVal val As BrokenRules) As Boolean
                If val Is Nothing Then
                    Return False
                Else
                    For Each rle As IRule In val
                        If rle.Severity = RuleSeverity.Critical Then
                            Return True
                        End If
                    Next
                    Return False
                End If
            End Function

            <Extension> Public Function GetRule(val As IEnumerable(Of IRule), ruleName As String, propname As String) As IRule
                Return (From itm As IRule In val Where itm.RuleName.CompareStringsWithNull(ruleName) AndAlso (itm.PropertyName.CompareStringsWithNull(propname))).FirstOrDefault
            End Function

            <Extension> Public Function GetRule(val As ITypeRules, ruleName As String, propname As String) As IRule
                Return GetRule(val.ListOfRules(True), ruleName, propname)
            End Function

            <Extension()> Public Function CheckRule(ByVal rules As ITypeRules, ByVal bo As IRuledItem, ruleName As String, propName As String) As BrokenRule
                Dim val As IRule = GetRule(rules, ruleName, propName)
                Return CheckRule(val, bo)
            End Function

            <Extension()> Public Function CheckRule(ByVal rules As ITypeRules, ByVal bo As IRuledItem, ruleName As String) As BrokenRule
                Return CheckRule(rules, bo, ruleName, "")
            End Function

        End Module


End Namespace
