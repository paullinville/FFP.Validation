
Namespace CSLA
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="rule"></param>
    ''' <returns>True if rule is broken. False if rule is not broken.</returns>
    ''' <remarks></remarks>
    Public Delegate Function RuleHandler(ByVal rule As Rule) As Boolean

End Namespace
