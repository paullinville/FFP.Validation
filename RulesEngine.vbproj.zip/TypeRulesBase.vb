
Imports FFP.Utilities.Extensions
Namespace CSLA
    Public MustInherit Class TypeRulesBase
        Implements ITypeRules


        Public Sub New()
            lvRuleList = New SimpleRuleList
            lvDeleteRuleList = New SimpleRuleList
            AddClassRules()
        End Sub

        Private lvRuleList As SimpleRuleList
        Public ReadOnly Property RuleList() As SimpleRuleList
            Get
                Return lvRuleList
            End Get
        End Property

        Public Sub AddRule(ByVal rule As IRule)
            lvRuleList.AddRule(rule)
        End Sub

        Private lvDeleteRuleList As SimpleRuleList
        Public ReadOnly Property DeleteRuleList() As SimpleRuleList
            Get
                Return lvDeleteRuleList
            End Get
        End Property

        Public Overridable Sub RemoveRule(ByVal rulename As String)
            RuleList.Remove((From itm As IRule In RuleList Where itm.RuleName = rulename).FirstOrDefault)
        End Sub

        Public Overridable Sub RemoveRule(ByVal rulename As String, ByVal propertyName As String)
            RuleList.Remove((From itm As IRule In RuleList Where itm.RuleName = rulename AndAlso itm.PropertyName = propertyName).FirstOrDefault)
        End Sub

        Public Overridable Sub RemoveRule(rule As IRule)
            RuleList.Remove((From itm As IRule In RuleList Where itm.RuleName.CompareAbsolute(rule.RuleName) AndAlso itm.PropertyName.CompareAbsolute(rule.PropertyName)).FirstOrDefault)
        End Sub

        Public Overridable Sub CheckRules(ByVal bo As IRulesChecked) Implements ITypeRules.CheckRules
            For Each rle As IRule In RuleList
                bo.AddBrokenRule(rle.CheckRule(bo))
            Next
        End Sub

        Public Overridable Sub CheckDeleteRules(ByVal bo As IRulesChecked) Implements ITypeRules.CheckDeleteRules
            For Each rle As IRule In DeleteRuleList
                bo.AddDeleteBrokenRule(rle.CheckRule(bo))
            Next
        End Sub

        Public MustOverride ReadOnly Property TypeFor() As IEnumerable(Of Type) Implements ITypeRules.TypeFor

        Protected MustOverride Sub AddClassRules()

        Public Overridable Function IsFor(objFor As Object) As Boolean Implements ITypeRules.IsFor
            Return TypeFor.Equals(objFor.GetType())
        End Function

        Public Function ListOfRules(includeDelete As Boolean) As IEnumerable(Of IRule) Implements ITypeRules.ListOfRules
            Dim lst As New List(Of IRule)
            If includeDelete Then
                lst.AddRange(DeleteRuleList.Cast(Of IRule))
            End If
            lst.AddRange(RuleList.Cast(Of IRule))
            Return lst
        End Function


    End Class
End Namespace
