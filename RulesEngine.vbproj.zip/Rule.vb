Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    <Serializable()> Public Class Rule
        Implements IRule

        Public Const STR_EMPTY As String = "(Empty)"
        <Obsolete("Use STR_EMPTY instead. See task 5018"), System.ComponentModel.EditorBrowsable(ComponentModel.EditorBrowsableState.Never)>
        Public Const STR_HTML_EMPTY As String = "(Empty)"
        Protected Sub New()

        End Sub

        Public Sub New(Rule As String, Description As String)
            RuleName = Rule
            Me.Description = Description
        End Sub

        Public Sub New(Rule As String, Description As String, [Property] As String, handler As RuleHandler)
            RuleName = Rule
            Me.Description = Description
            PropertyName = [Property]
            RuleHandler = handler
        End Sub

        Public Sub New(Rule As String, Description As String, [Property] As String)
            RuleName = Rule
            Me.Description = Description
            PropertyName = [Property]
        End Sub

        Public Sub New(handler As RuleHandler)
            RuleName = ""
            Me.Description = ""
            RuleHandler = handler
        End Sub

        Public Sub New(Rule As String, Description As String, handler As RuleHandler)
            RuleName = Rule
            Me.Description = Description
            RuleHandler = handler
        End Sub


        Private lvBO As IRulesChecked
        Public Property BusinessObject() As IRulesChecked Implements IRule.BusinessObject
            Get
                Return lvBO
            End Get
            Set(value As IRulesChecked)
                lvBO = value
            End Set
        End Property

        Public Property PropertyValue() As Object Implements IRule.PropertyValue
            Get
                If PropertyName.IsNullOrBlank Then
                    Return Nothing
                Else
                    Return BusinessObject.PropertyValue(PropertyName)
                End If

            End Get
            Private Set(value As Object)
            End Set
        End Property



        Private Function InvokedRuleBroken() As Boolean
            Return RuleHandler.Invoke(Me)
        End Function

        <System.ComponentModel.Bindable(False)>
        Public Property RuleHandler() As RuleHandler

        Public Overridable Property AllowedValue() As Object Implements IRule.AllowedValue

        Public Property Severity() As RuleSeverity = RuleSeverity.Critical Implements IRule.Severity

        Public Property PropertyName() As String Implements IRule.PropertyName

        Public Property RuleName() As String = "" Implements IRule.RuleName

        Private _description1 As String
        Public Property Description() As String Implements IRule.Description
            Get
                Return Resources.Strings.GetResourceString(RuleName, _description1)
            End Get
            Set
                _description1 = Value
            End Set
        End Property

        Public Overridable Function HandlesProperty(propName As String) As Boolean Implements IRule.HandlesProperty
            Return PropertyName.CompareAbsolute(propName)
        End Function

        Private lvIsBroken As Boolean = False


        Public Overridable Property IsBroken() As Boolean Implements IRule.IsBroken
            Get
                Return lvIsBroken OrElse InvokedRuleBroken()
            End Get
            Protected Set(value As Boolean)
                lvIsBroken = value
            End Set
        End Property


        Public Overrides Function Equals(obj As Object) As Boolean 'Implements IRule.Equals
            If obj Is Nothing Then Return False
            If TypeOf obj Is IRule Then
                Dim ruleToCompare As IRule = CType(obj, IRule)
                If ruleToCompare.RuleName.CompareAbsolute(RuleName) AndAlso ruleToCompare.PropertyName.CompareAbsolute(PropertyName) Then
                    If lvBO Is Nothing AndAlso ruleToCompare.BusinessObject Is Nothing Then
                        Return True
                    ElseIf lvBO IsNot Nothing AndAlso ruleToCompare.BusinessObject IsNot Nothing Then
                        Return lvBO.GetType.Equals(ruleToCompare.BusinessObject.GetType)
                    Else
                        Return False
                    End If
                End If
            End If
            Return False
        End Function

        Public Overrides Function ToString() As String
            Return Description
        End Function

        Public Overrides Function GetHashCode() As Integer
            If lvBO Is Nothing Then
                Return (RuleName & PropertyName).GetHashCode
            Else
                Return (RuleName & PropertyName & lvBO.GetType.FullName).GetHashCode
            End If
        End Function
    End Class


End Namespace
