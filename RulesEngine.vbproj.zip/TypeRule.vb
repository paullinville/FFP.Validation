Imports System.Security.Cryptography
Imports FFP.CoreUtilities
Imports FFP.Utilities.Extensions
Namespace CSLA
    Public MustInherit Class TypeRule(Of T)
        Implements ITypeRules


        Public Sub New()
            Rule = AddTypeRule()
        End Sub

        Public Sub New(name As String, description As String)
            Me.New()
            Rule.RuleName = name
            Rule.Description = description
        End Sub

        Protected Property Rule As IRule

        Public MustOverride Sub CheckRules(bo As IRulesChecked) Implements ITypeRules.CheckRules

        Public MustOverride Sub CheckDeleteRules(bo As IRulesChecked) Implements ITypeRules.CheckDeleteRules

        Public MustOverride Function RuleBroke(target As IRule) As Boolean

        Public Overridable ReadOnly Property TypeFor() As IEnumerable(Of Type) Implements ITypeRules.TypeFor
            Get
                Return {GetType(T)}
            End Get
        End Property

        Protected Overridable Function AddTypeRule() As IRule
            Return New Rule(RuleName, RuleDescription, AddressOf RuleBroke)
        End Function

        Protected Overridable Function RuleName() As String
            Return Me.GetType().Name.BreakByCapitols()
        End Function

        Protected Overridable Property RuleDescription() As String


        Public Overridable Function IsFor(objFor As Object) As Boolean Implements ITypeRules.IsFor
            Return TypeFor.Contains(objFor.GetType())
        End Function

        Protected Function BO() As T
            Return CType(Rule.BusinessObject, T)
        End Function

        Public MustOverride Function ListOfRules(includeDelete As Boolean) As IEnumerable(Of IRule) Implements ITypeRules.ListOfRules

    End Class
End Namespace