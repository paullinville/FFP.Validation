Imports System.Collections.Specialized
Imports FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    Public Class RuleOutput

        Protected Property rule As IRule
        Public Sub New(rl As IRule)
            rule = rl
        End Sub

        Public Overridable Function Output() As String
            Dim strBld As New Text.StringBuilder
            If TypeOf rule.BusinessObject Is IIdentifiable Then
                strBld.Append(CType(rule.BusinessObject, IIdentifiable).FriendlyName.Trim() & " " & rule.BusinessObject.ToString)
            Else
                strBld.Append(rule.BusinessObject.GetType.Name.Trim() & " " & rule.BusinessObject.ToString)
            End If

            strBld.Append(" Broken Rule with severity of ")
            strBld.Append(rule.Severity.EnumName)
            If Not String.IsNullOrEmpty(rule.PropertyName) Then
                strBld.Append(ControlChars.NewLine)
                strBld.Append("Property: ")
                strBld.Append(rule.PropertyName.Trim & ";")
                strBld.Append(" Current Value: ")
                If (rule.PropertyValue Is Nothing) OrElse (TypeOf rule.PropertyValue Is Guid AndAlso CType(rule.PropertyValue, Guid).IsEmpty) OrElse (TypeOf rule.PropertyValue Is String AndAlso CType(rule.PropertyValue, String).IsEmpty) Then
                    strBld.Append(CSLA.Rule.STR_EMPTY)
                Else
                    strBld.Append(rule.PropertyValue.ToString)
                End If
            End If
            strBld.Append(ControlChars.NewLine)
            strBld.Append("Description: ")
            strBld.Append(rule.Description)
            Return strBld.ToString
        End Function


    End Class
End Namespace
