Imports CSLA.FFP.BO.Interfaces
Imports FFP.Utilities

Namespace CSLA
    Public MustInherit Class TypeRuleBase(Of T)
        Inherits TypeRule(Of T)

        Public Sub New()
            MyBase.New()
        End Sub

        Public Sub New(name As String, description As String)
            MyBase.New(name, description)
        End Sub

        Public Overrides Sub CheckRules(bo As IRulesChecked)
            If Rule IsNot Nothing Then
                bo.AddBrokenRule(Rule.CheckRule(bo))
            End If
        End Sub

        Public Overrides Sub CheckDeleteRules(bo As IRulesChecked)

        End Sub

        Public Overrides Function ListOfRules(includeDelete As Boolean) As IEnumerable(Of IRule)
            If includeDelete Then
                Return {}
            Else
                Return {Rule}
            End If
        End Function
    End Class
End Namespace