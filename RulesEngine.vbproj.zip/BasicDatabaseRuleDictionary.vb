Imports FFP.CoreUtilities.Extensions
Imports System.Reflection

Namespace CSLA



    Public MustInherit Class BasicDatabaseRuleDictionary
        Inherits BasicRuleDictionary
        Public Const Database_Rule As String = "Database_Rule"
        Public Sub New()
            GoodGroups.Add(Database_Rule)
        End Sub

    End Class

End Namespace
